<?php
include('logo.php');
include("config.php");
$sno = isset($_GET['updateid']) ? $_GET['updateid'] : null;
$sql = "SELECT * FROM `crud` WHERE `sno` = '$sno'";
$result = mysqli_query($connection, $sql);

if ($result) {
    $row = mysqli_fetch_assoc($result);
    $name = $row['name'];
    $email = $row['email'];
    $mobile = $row['mobile'];
    $password = $row['password'];
} 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $password = $_POST['password'];

    $sql = "UPDATE `crud` SET `name`='$name', `email`='$email', `mobile`='$mobile', `password`='$password', `date`=current_timestamp() WHERE `sno`='$sno'";

    $result = mysqli_query($connection, $sql);
    if ($result) {
        header("Location: display.php");
        exit;
    } 
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Record</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-5">
        <form action="update.php?updateid=<?php echo $sno; ?>" method="post">
            <div class="form-group mt-5">
                <label for="name" class="text-dark"><b>Name</b></label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name" value="<?php echo $name; ?>">
            </div>
            <div class="form-group">
                <label for="email" class="text-dark"><b>Email</b></label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" value="<?php echo $email; ?>">
            </div>
            <div class="form-group">
                <label for="mobile" class="text-dark"><b>Mobile</b></label>
                <input type="tel" class="form-control" id="mobile"  name="mobile" placeholder="Enter your mobile" value="<?php echo $mobile; ?>">
            </div>
            <div class="form-group">
                <label for="password" class="text-dark"><b>Password</b></label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" value="<?php echo $password; ?>">
            </div>
            <button type="submit" class="btn btn-success">Update</button>
        </form>
    </div>
</body>
</html>
