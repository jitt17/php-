<?php
include('logo.php');
    if(($_SERVER['REQUEST_METHOD']) == 'POST'){
        include("config.php");
        $name = $_POST['name'];
        $email = $_POST['email'];
        $mobile = $_POST['mobile'];
        $password = $_POST['password'];
        if($name == null){
            header("location: user.php");
        }
        else{
        $sql = "INSERT INTO `crud` (`name`, `email`, `mobile`, `password`,`date`) VALUES ('$name', '$email', '$mobile', '$password',current_timestamp())";
        $result = mysqli_query($connection,$sql);
        if($result)
        {
            header("location: display.php");
        }
    }
}
    

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

</head>
<body>
    
        <div class="container my-5">
        <form action = "user.php" method = "post"> 
            <div class="form-group mt-5">
                <label for="name" class="text-dark"><strong>Name</strong></label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name">
            </div>
            <div class="form-group">
                <label for="email" class="text-dark"><strong>Email</strong></label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Enter your mail...">
            </div>
            <div class="form-group">
                <label for="email" class="text-dark"><strong>Mobile</strong></label>
                <input type="tel" class="form-control" name="mobile"  id="mobile" placeholder="Enter your mobile">
           
            </div>
            <div class="form-group">
                <label for="email" class="text-dark"><strong>Password</strong></label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Enter password">
            </div>
            <div class="d-flex justify-content-center">
            <button type="submit" class="btn btn-outline-success text-decoration-none  mr-3">Submit</button>
            <a href="display.php" class="btn btn-outline-info text-decoration-none  ml-3">Show Data</a>
            
        </div>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
</body>
</html>