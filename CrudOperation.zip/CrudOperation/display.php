<?php
    include('logo.php');
    include('config.php');

    // Set the number of records per page
    $records_per_page = 10;

    // Get the current page from the URL, default is page 1
    $current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

    // Calculate the starting record index
    $offset = ($current_page - 1) * $records_per_page;

    // Fetch records for the current page
    $sql = "SELECT * FROM crud LIMIT $offset, $records_per_page";
    $result = mysqli_query($connection, $sql);

    // Count total records to determine total pages
    $total_sql = "SELECT COUNT(*) FROM crud";
    $total_result = mysqli_query($connection, $total_sql);
    $total_rows = mysqli_fetch_array($total_result)[0];
    $total_pages = ceil($total_rows / $records_per_page);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <a href="user.php" class="btn btn-outline-success text-decoration-none text-success my-2">New +</a>
        <table class="table">
            <thead>
                <tr >
                    <th scope="col">No.</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Mobile</th>
                    <th scope="col">Password</th>
                    <th scope="col">Operation</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    if ($result) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $sno = $row['sno'];
                            $name = $row['name'];
                            $email = $row['email'];
                            $mobile = $row['mobile'];
                            $password = $row['password'];

                            echo '<tr class="p-0">
                                    <th scope="row" >' . $sno . '</th>
                                    <td class="p-1">' . $name . '</td>
                                    <td class="p-1">' . $email . '</td>
                                    <td class="p-1">' . $mobile . '</td>
                                    <td class="p-1">' . $password . '</td>
                                    <td class="p-1">
                                        <a href="update.php?updateid='.$sno.'" class="btn btn-outline-primary text-decoration-none ">Update</a>
                                        <a href="delete.php?deleteid='.$sno.'" class="btn btn-outline-danger text-decoration-none ">Delete</a>
                                    </td>
                                  </tr>';
                        }
                    }
                ?>
            </tbody>
        </table>

        <!-- Pagination Links -->
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center">
                <?php
                    for ($page = 1; $page <= $total_pages; $page++) {
                        echo '<li class="page-item ' . ($page == $current_page ? 'active' : '') . '">
                                <a class="page-link" href="?page=' . $page . '">' . $page . '</a>
                              </li>';
                    }
                ?>
            </ul>
        </nav>
    </div>
</body>
</html>
