<?php
 $connection = mysqli_connect("localhost","root","","crudoperation");
 if(!$connection)
 {
    die(mysqli_connect_error());
 }
 
?>