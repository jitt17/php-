<?php
    
    include("config.php");
    $sno = isset($_GET['updateid']) ? $_GET['updateid'] : null;
    $sql = "SELECT * FROM `crud` WHERE `sno` = '$sno'";
    $result = mysqli_query($connection,$sql);
    //if($result && mysqli_num_rows($result)>0){
        $row = mysqli_fetch_assoc($result);
        $name = $row['name'];
        $email = $row['email'];
        $mobile = $row['mobile'];
        $password = $row['password'];
    
    if(($_SERVER['REQUEST_METHOD']) == 'POST'){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $mobile = $_POST['mobile'];
        $password = $_POST['password'];
        
       // $sql = "UPDATE `crud` SET `sno`='$sno',`name`='$name',`email`='$email',`mobile`='$mobile',`password`='$password',`date`=current_timestamp() WHERE 'sno'='$sno'";
        $sql = "UPDATE `crud` SET `name`='$name', `email`='$email', `mobile`='$mobile', `password`='$password', `date`=current_timestamp() WHERE `sno`='$sno'";

        $result = mysqli_query($connection,$sql);
        if($result)
        {
            header("location:display.php");
        }
    }

    
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

</head>
<body>
    
        <div class="container my-5">
        <form action = "update.php" method = "post"> 
            <div class="form-group mt-5">
                <label for="name"><strong>Name</strong></label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name" value=<?php echo $name; ?>>
            </div>
            <div class="form-group">
                <label for="email"><strong>Email</strong></label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Enter your mail" value=<?php echo $email; ?>>
            </div>
            <div class="form-group">
                <label for="email"><strong>Mobile</strong></label>
                <input type="tel" class="form-control" name="mobile" id="mobile" placeholder="Enter your mail" value=<?php echo $mobile; ?>>
           
            </div>
            <div class="form-group">
                <label for="email"><strong>Password</strong></label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" value=<?php echo $password; ?>>
            </div>
            <div class="d-flex justify-content-center">
            <button type="submit" class="btn btn-outline-success text-decoration-none  mr-3">Update</button>
            
        </div>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
</body>
</html>