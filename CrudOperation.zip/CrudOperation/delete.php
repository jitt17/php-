<?php
    include("config.php");
    if(isset($_GET['deleteid']))
    {
        $sno = $_GET['deleteid'];
        $sql = "DELETE FROM `crud` WHERE `sno` = '$sno'";
        $result = mysqli_query($connection,$sql);
        if($result){
            header("location:display.php");
        }
    }

?>
