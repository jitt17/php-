<?php
    $connection = mysqli_connect("localhost","root","","jitt1");
    if(!$connection)
    {
        die("Connection Failed ");
    }

?>