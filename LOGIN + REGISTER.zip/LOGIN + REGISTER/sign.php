<?php
    $showAlert = false;
    $showError = false;
    if($_SERVER['REQUEST_METHOD'] == "POST"){
    include "config.php";
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];

    $sql = "select * from user Where username = '$username'";
    $result =mysqli_query($connection,$sql);
    $num = mysqli_num_rows($result);
    if($num >0){
        $showError = "User Exists already";
    }
    else{
        if($cpassword == $password){
            $hash = password_hash($password,PASSWORD_DEFAULT);

            $sql = "INSERT INTO `user` ( `username`, `email`, `password`, `date`) VALUES ( '$username', '$email', '$hash', current_timestamp())";
            $request = mysqli_query($connection,$sql);
            if($request){
            $showAlert = true;
            }
        }
        else{
            $showError = "password not match..";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

</head>
<body>
    <?php
        include "nav.php";
    ?>
    <?php
    if($showAlert){
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success !!</strong> Your account created..
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>';
    }
    if($showError){
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Error !!</strong>'.$showError.'
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>';
    }
    ?>
    <div class="container">
        <form action = "sign.php" method = "post"> 
            <div class="form-group">
                <label for="name"><strong>Username</strong></label>
                <input type="name" class="form-control" id="name" name="username" placeholder="Enter name..." required>
            </div>
            <div class="form-group">
                <label for="email"><strong>Email</strong></label>
                <input type="email" class="form-control" id="email" name="email" required placeholder="Enter mail...">
            </div>
            <div class="form-group">
                <label for="email"><strong>Password</strong></label>
                <input type="password" class="form-control" id="password" name="password" require placeholder="Enter password">
            </div>
            <div class="form-group">
                <label for="password"> <strong>Conform password</strong></label>
                <input type="password" class="form-control" id="password" name="cpassword" require placeholder="Repeat password...">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
</body>
</html>